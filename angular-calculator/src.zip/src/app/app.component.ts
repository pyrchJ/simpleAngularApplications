import { Component } from '@angular/core';

@Component({
  selector: 'app-root', 
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
export class AppComponent {
  title = 'angular-calculator';

displayText = '';
number1: number; //Simple example with 2 numbers
number2: number; 
operator = ''; 
calculationValue = ''; 
answered = false; 

operatorSet = false; 

pressKey(key: string) {
  if (key === '/' || key === 'x' || key === '-' || key === '+') {
     const lastKey = this.displayText[this.displayText.length - 1];
     if (lastKey === '/' || lastKey === 'x' || lastKey === '-' || lastKey === '+')  {
       this.operatorSet = true;
     }
     if ((this.operatorSet) || (this.displayText === '')) {
       return;
     }
     this.number1 = parseFloat(this.displayText);
     this.operator = key;
     this.operatorSet = true;
  }
  
    this.displayText += key;
  
  
}
returnAnswer() {
  this.calculationValue = this.displayText;
  this.number2 = parseFloat(this.displayText.split(this.operator)[1]);
  if (this.operator === '/') {
    
    this.displayText = (this.number1 / this.number2).toString();

  } else if (this.operator === 'x') {
   
    this.displayText = (this.number1 * this.number2).toString();

  } else if (this.operator === '-') {
    this.displayText = (this.number1 - this.number2).toString();
  } else if (this.operator === '+') {
    this.displayText = (this.number1 + this.number2).toString();
   
  } 

  this.answered = true;
}
Clear(){
  window.location.reload();
  
  
}
}
